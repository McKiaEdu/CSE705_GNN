"""Figure functions: one per report figure. matplotlib, Agg backend, sized for
IEEE single-column width. Each function writes one PDF file; the aggregation
layer (aggregation.py) is the only thing that computes the numbers.
"""

from __future__ import annotations

import math
import os
from typing import Any

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd
import torch
from sklearn.manifold import TSNE

from .aggregation import Aggregate, EnergyCurve, GeometricMean

FIGURE_WIDTH_INCHES = 3.5
FIGURE_HEIGHT_INCHES = 2.6
MIN_FONT_SIZE = 8

# categorical palette, validated colorblind-safe order (dataviz skill reference)
ARCHITECTURE_ORDER = ["gcn", "sage", "gat"]
ARCHITECTURE_COLORS = {"gcn": "#2a78d6", "sage": "#008300", "gat": "#e87ba4"}
ARCHITECTURE_MARKERS = {"gcn": "o", "sage": "s", "gat": "^"}
ARCHITECTURE_LINESTYLES = {"gcn": "-", "sage": "--", "gat": ":"}

MITIGATION_SERIES_ORDER = ["residual", "pairnorm", "jk", "pairnorm+residual", "gcnii"]
MITIGATION_COLORS = dict(zip(MITIGATION_SERIES_ORDER, ["#2a78d6", "#008300", "#e87ba4", "#eda100", "#1baf7a"]))
MITIGATION_MARKERS = dict(zip(MITIGATION_SERIES_ORDER, ["o", "s", "^", "D", "v"]))
MITIGATION_LINESTYLES = dict(zip(MITIGATION_SERIES_ORDER, ["-", "--", ":", "-.", "-"]))


def _NewFigure(nPanels: int = 1) -> tuple[plt.Figure, Any]:
    fig, axes = plt.subplots(1, nPanels, figsize=(FIGURE_WIDTH_INCHES, FIGURE_HEIGHT_INCHES))
    for ax in axes if nPanels > 1 else [axes]:
        ax.tick_params(labelsize=MIN_FONT_SIZE)
        ax.xaxis.label.set_size(MIN_FONT_SIZE + 1)
        ax.yaxis.label.set_size(MIN_FONT_SIZE + 1)
    return fig, axes


def _SaveFigure(fig: plt.Figure, outputPath: str) -> None:
    os.makedirs(os.path.dirname(outputPath) or ".", exist_ok=True)
    fig.tight_layout()
    fig.savefig(outputPath, format="pdf")
    plt.close(fig)


def PlotAccuracyVsDepth(table: pd.DataFrame, outputPath: str) -> None:
    """Arm A's headline: test accuracy vs depth, one series per architecture."""
    fig, ax = _NewFigure()
    for convType in ARCHITECTURE_ORDER:
        subset = table[(table["convType"] == convType) & (table["mitigations"].apply(len) == 0)]
        agg = Aggregate(subset, ["numLayers"]).sort_values("numLayers")
        ax.errorbar(
            agg["numLayers"],
            agg["testAccuracy_mean"],
            yerr=agg["testAccuracy_std"],
            label=convType,
            color=ARCHITECTURE_COLORS[convType],
            marker=ARCHITECTURE_MARKERS[convType],
            linestyle=ARCHITECTURE_LINESTYLES[convType],
            markersize=4,
            linewidth=1.2,
            capsize=2,
        )
    ax.set_xscale("log", base=2)
    ax.set_xlabel("depth (layers)")
    ax.set_ylabel("test accuracy")
    ax.legend(fontsize=MIN_FONT_SIZE)
    _SaveFigure(fig, outputPath)


def PlotEnergyVsLayer(
    records: list[dict], outputPath: str, capture: str = "checkpointMetrics", labels: list[str] | None = None
) -> None:
    """Normalized per-dimension energy vs layer index, log y-axis, one series
    per record (e.g. one per architecture at a fixed depth). Reads `capture`
    (checkpointMetrics by default: the state the reported accuracy comes from).
    """
    fig, ax = _NewFigure()
    labels = labels or [r["config"]["convType"] for r in records]
    for record, label in zip(records, labels):
        bandIndices, normalizedEnergy = EnergyCurve(record, capture)
        color = ARCHITECTURE_COLORS.get(label)
        ax.plot(bandIndices, normalizedEnergy, label=label, color=color, marker="o", markersize=3, linewidth=1.2)
    ax.set_yscale("log")
    ax.set_xlabel("layer index")
    ax.set_ylabel("normalized energy")
    ax.legend(fontsize=MIN_FONT_SIZE)
    _SaveFigure(fig, outputPath)


def PlotMadVsDepth(table: pd.DataFrame, outputPath: str, capture: str = "checkpoint") -> None:
    """MAD at the last band index vs depth, one series per architecture."""
    fig, ax = _NewFigure()
    column = f"{capture}MadAtLastBand"
    for convType in ARCHITECTURE_ORDER:
        subset = table[(table["convType"] == convType) & (table["mitigations"].apply(len) == 0)]
        agg = Aggregate(subset, ["numLayers"]).sort_values("numLayers")
        ax.errorbar(
            agg["numLayers"],
            agg[f"{column}_mean"],
            yerr=agg[f"{column}_std"],
            label=convType,
            color=ARCHITECTURE_COLORS[convType],
            marker=ARCHITECTURE_MARKERS[convType],
            linestyle=ARCHITECTURE_LINESTYLES[convType],
            markersize=4,
            linewidth=1.2,
            capsize=2,
        )
    ax.set_xscale("log", base=2)
    ax.set_xlabel("depth (layers)")
    ax.set_ylabel("MAD (last band index)")
    ax.legend(fontsize=MIN_FONT_SIZE)
    _SaveFigure(fig, outputPath)


def PlotArmDDepthCurve(table: pd.DataFrame, outputPath: str) -> None:
    """Arm D: Jumping Knowledge on all three architectures against depth.

    Separate from PlotMitigationAblation, which varies the mitigation on GCN
    alone. This holds the mitigation fixed and varies the architecture, which
    is what shows the transfer result: two curves hold with depth and one does
    not. The majority-class floor is drawn because GraphSAGE+JK's depth-32
    value is only meaningful relative to it.
    """
    fig, ax = _NewFigure()
    for convType in ARCHITECTURE_ORDER:
        mitigated = table[
            (table["convType"] == convType) & (table["mitigations"].apply(lambda m: tuple(m) == ("jk",)))
        ]
        agg = Aggregate(mitigated, ["numLayers"]).sort_values("numLayers")
        ax.errorbar(
            agg["numLayers"],
            agg["testAccuracy_mean"],
            yerr=agg["testAccuracy_std"],
            label=f"{convType} + jk",
            color=ARCHITECTURE_COLORS[convType],
            marker=ARCHITECTURE_MARKERS[convType],
            linestyle=ARCHITECTURE_LINESTYLES[convType],
            markersize=4,
            linewidth=1.2,
            capsize=2,
        )
    # majority-class floor from the test-split label counts (Section 3)
    ax.axhline(0.319, color="0.45", linestyle=(0, (1, 2)), linewidth=1.0)
    # right-aligned at the last depth: the lower-left corner holds the legend
    ax.annotate(
        "majority-class floor",
        xy=(32, 0.319),
        xytext=(-2, 4),
        textcoords="offset points",
        ha="right",
        fontsize=MIN_FONT_SIZE - 1,
        color="0.35",
    )
    ax.set_xscale("log", base=2)
    ax.set_xlabel("depth (layers)")
    ax.set_ylabel("test accuracy")
    ax.legend(fontsize=MIN_FONT_SIZE, loc="lower left")
    _SaveFigure(fig, outputPath)


def PlotMitigationAblation(table: pd.DataFrame, outputPath: str) -> None:
    """Arm B (4 mitigation combos) plus arm C (GCNII): test accuracy vs depth,
    one series per mitigation, 5 total. Whether this should split across
    multiple panels for legibility is not resolved here; this renders all 5
    on one axes."""
    fig, ax = _NewFigure()
    for seriesName in MITIGATION_SERIES_ORDER:
        if seriesName == "gcnii":
            subset = table[table["convType"] == "gcnii"]
        else:
            mitigationTuple = tuple(sorted(seriesName.split("+")))
            subset = table[(table["convType"] == "gcn") & (table["mitigations"] == mitigationTuple)]
        agg = Aggregate(subset, ["numLayers"]).sort_values("numLayers")
        ax.errorbar(
            agg["numLayers"],
            agg["testAccuracy_mean"],
            yerr=agg["testAccuracy_std"],
            label=seriesName,
            color=MITIGATION_COLORS[seriesName],
            marker=MITIGATION_MARKERS[seriesName],
            linestyle=MITIGATION_LINESTYLES[seriesName],
            markersize=4,
            linewidth=1.2,
            capsize=2,
        )
    ax.set_xscale("log", base=2)
    ax.set_xlabel("depth (layers)")
    ax.set_ylabel("test accuracy")
    ax.legend(fontsize=MIN_FONT_SIZE, ncol=1)
    _SaveFigure(fig, outputPath)


def PlotLossCurves(records: list[dict], outputPath: str, labels: list[str] | None = None) -> None:
    """trainingCurve at depth 32, baseline vs mitigated: the diagnostic that
    separates "never trained" from "trained then oversmoothed"."""
    fig, ax = _NewFigure()
    labels = labels or [r["runId"] for r in records]
    for record, label in zip(records, labels):
        epochs = [e["epoch"] for e in record["trainingCurve"]]
        trainLosses = [e["trainLoss"] for e in record["trainingCurve"]]
        ax.plot(epochs, trainLosses, label=label, linewidth=1.2)
    ax.axhline(y=math.log(7), color="gray", linestyle=":", linewidth=0.8, label="ln 7 (untrained)")
    ax.set_xlabel("epoch")
    ax.set_ylabel("train loss")
    ax.legend(fontsize=MIN_FONT_SIZE)
    _SaveFigure(fig, outputPath)


def PlotEnergyShift(table: pd.DataFrame, outputPath: str) -> None:
    """epoch0Metrics vs checkpointMetrics vs finalMetrics: three points per
    depth, testing whether energy falls or rises over training at a working
    depth.

    Averaged across seeds with GeometricMean, not a plain mean: the per-seed
    last-band energy is right-skewed (a minority of seeds run several times
    higher than the rest, more so at greater depth), so an arithmetic mean is
    pulled toward those seeds rather than describing a typical one. The same
    reasoning applies, more severely, to the energy-ratio quantity reported
    elsewhere; the effect here is smaller since this is raw energy rather
    than a ratio with a near-zero denominator.
    """
    fig, ax = _NewFigure()
    captureLabels = ["epoch0", "checkpoint", "final"]
    for depth in sorted(table["numLayers"].unique()):
        subset = table[table["numLayers"] == depth]
        means = [GeometricMean(subset[f"{c}EnergyAtLastBand"]) for c in captureLabels]
        ax.plot(captureLabels, means, marker="o", markersize=4, linewidth=1.2, label=f"depth={depth}")
    ax.set_yscale("log")
    ax.set_ylabel("energy (last band index)")
    ax.legend(fontsize=MIN_FONT_SIZE)
    _SaveFigure(fig, outputPath)


def PlotEmbeddingProjection(embeddingPaths: dict[str, str], labels, outputPath: str) -> None:
    """t-SNE of saved embeddings, coloured by data.y, one panel per entry in
    embeddingPaths (e.g. shallow vs deep). Fitted separately per panel: a
    shared fit would impose one neighbourhood structure on both and
    manufacture the difference the figure exists to show. random_state=0 and
    perplexity=30 belong in the figure caption."""
    fig, axes = _NewFigure(nPanels=len(embeddingPaths))
    axes = axes if len(embeddingPaths) > 1 else [axes]
    for ax, (panelLabel, path) in zip(axes, embeddingPaths.items()):
        embedding = torch.load(path).numpy()
        projection = TSNE(n_components=2, random_state=0, perplexity=30).fit_transform(embedding)
        ax.scatter(projection[:, 0], projection[:, 1], c=labels, s=2, cmap="tab10")
        ax.set_title(panelLabel, fontsize=MIN_FONT_SIZE)
        ax.set_xticks([])
        ax.set_yticks([])
    _SaveFigure(fig, outputPath)
